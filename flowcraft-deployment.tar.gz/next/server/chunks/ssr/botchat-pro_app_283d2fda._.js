module.exports=[30043,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},83474,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(30043).default,width:256,height:256}}];

//# sourceMappingURL=botchat-pro_app_283d2fda._.js.map