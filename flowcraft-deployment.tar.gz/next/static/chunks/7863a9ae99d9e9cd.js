__turbopack_load_page_chunks__("/_app", [
  "static/chunks/ff929660b1479331.js",
  "static/chunks/a135c47ab6dec819.js",
  "static/chunks/turbopack-e67a98a894c8f020.js"
])
