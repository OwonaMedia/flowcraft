var R=require("../../chunks/[turbopack]_runtime.js")("server/app/api-fallback/route.js")
R.c("server/chunks/[root-of-the-server]__d3f432ee._.js")
R.c("server/chunks/ccf52_next_dist_d02ee34e._.js")
R.m(73023)
R.m(39533)
module.exports=R.m(39533).exports
