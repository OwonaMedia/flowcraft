var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__9343e77e._.js")
R.c("server/chunks/ccf52_next_dist_31d02811._.js")
R.c("server/chunks/ccf52_next_dist_bd7f69dd._.js")
R.c("server/chunks/ccf52_next_a87bf419._.js")
R.m(25170)
R.m(72640)
module.exports=R.m(72640).exports
