var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__d09bf6b8._.js")
R.c("server/chunks/ssr/[root-of-the-server]__232991cb._.js")
R.m(62223)
module.exports=R.m(62223).exports
