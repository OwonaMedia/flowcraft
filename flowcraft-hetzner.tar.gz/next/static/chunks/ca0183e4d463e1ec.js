__turbopack_load_page_chunks__("/_error", [
  "static/chunks/d8c6902a93f5f8c7.js",
  "static/chunks/a135c47ab6dec819.js",
  "static/chunks/turbopack-226392468db9f10e.js"
])
